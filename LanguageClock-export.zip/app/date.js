import document from "document";

//DATE
let date = document.getElementById('text_date');
let dayOfWeek = document.getElementById('text_dayOfWeek');

let monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

let dayNames = ["Sunday,","Monday,", "Tuesday,", "Wednesday,", "Thursday,", "Friday,", "Saturday,"];

export function updateDate() {
    let dayInfo = new Date();
    let day = dayInfo.getDay();
    let month = dayInfo.getMonth();
    let dayOfMonth = dayInfo.getDate();
  
    date.text = `${monthNames[month]} ${dayOfMonth}`;
    dayOfWeek.text = `${dayNames[day]}`;
}

