import document from "document"; 
import { battery } from "power";

//Battery - START
export let rectBattery = document.getElementById("rect_battery");
export const batteryWidth = rectBattery.width;

//Battery Draw - START
export function batteryDraw() {
  let level = battery.chargeLevel;
  let batteryPercentage = Math.floor(level);
  let lineWidth = Math.floor(batteryWidth*(batteryPercentage/100));

  if (batteryPercentage >= 30) {
      rectBattery.style.fill = "limegreen";
      rectBattery.width = lineWidth;
  } else {
      rectBattery.style.fill = "crimson";
      rectBattery.width = lineWidth;
  }
  
}
