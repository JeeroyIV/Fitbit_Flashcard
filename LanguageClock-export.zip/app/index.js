import clock from "clock";
import { today } from "user-activity";
import document from "document";
import { preferences } from "user-settings";
import * as util from "../common/utils";
import Steps from './steps.js';
import * as date from "./date.js";
import * as battery from "./battery.js";
import * as arrayShort from "./arrayShort.js";
import * as chooseWord from "./chooseWord.js";

clock.granularity = "minutes";

const clockStyle = document.getElementById("text_clock");

clock.ontick = (evt) => {
  let today = evt.date;
  let hours = today.getHours();
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = hours % 12 || 12;
  } else {
    // 24h format
    hours = util.zeroPad(hours);
  }
  let mins = util.zeroPad(today.getMinutes());
  clockStyle.text = `${hours}:${mins}`;
  
  Steps();  
  battery.batteryDraw();
  date.updateDate();
  
}



var word1 = document.getElementById("text_wordOne");
var word2 = document.getElementById("text_wordTwo");
var num = 1;
let img = document.getElementById("button_next");

word1.text=arrayShort.arrayShortOne[num];
word2.text=arrayShort.arrayShortTwo[num];

//chooseWord.handleFiles();

console.log("here1");

img.onclick = (e) => {
if (num > 999 || 0) {
  num = 1
} else {
  num++;
}
const displayWords = document.getElementById("displayWords");
word1.text=arrayShort.arrayShortOne[num];
word2.text=arrayShort.arrayShortTwo[num];
displayWords.animate("load");
}

