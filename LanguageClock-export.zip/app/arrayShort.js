export let arrayShortOne = ["","word1.1","word1.2","imported array"];
export let arrayShortTwo = ["","word2.1","word2.2","imported array"];
