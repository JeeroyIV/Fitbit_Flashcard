import document from "document"; 

var wordENG = document.getElementById("./wordFiles/eng.txt");

export function handleFiles(wordENG) {
console.log("here0");
    const file = wordENG.target.files[1];
    const reader = new FileReader();

    reader.onload = (event) => {
        const file = event.target.result;
        const allLines = file.split(/\r\n|\n/);
        // Reading line by line
        allLines.forEach((line) => {
            console.log(line);
        });
    };

    reader.onerror = (event) => {
        alert(event.target.error.name);
    };

    reader.readAsText(file);
}




