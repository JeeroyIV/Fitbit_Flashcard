import { today } from "user-activity";
import document from "document";

export default class Steps {
  constructor() {
    const stepsText = document.getElementById("text_steps");
    stepsText.text = (today.local.steps || 0);
  }
}